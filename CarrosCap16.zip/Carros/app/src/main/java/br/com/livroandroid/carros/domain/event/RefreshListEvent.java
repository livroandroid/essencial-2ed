package br.com.livroandroid.carros.domain.event;

// Objeto de evento para atualizar a lista de carros
public class RefreshListEvent {

}
