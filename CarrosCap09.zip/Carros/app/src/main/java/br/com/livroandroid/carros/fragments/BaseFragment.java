package br.com.livroandroid.carros.fragments;

import android.support.v4.app.Fragment;

public class BaseFragment extends Fragment {
}